# encoding: utf-8

class CreateMCategory < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `m_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(256) NOT NULL,
  `category_description` text NULL,
  `category_disp_order` int(11) NOT NULL,
  `del_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`category_id`),
  KEY `s1_key` (`category_id`,`insert_dt`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `m_category`;"
  end
end
