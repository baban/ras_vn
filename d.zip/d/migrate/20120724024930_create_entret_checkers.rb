# encoding: utf-8

class CreateEntretCheckers < ActiveRecord::Migration
  def change
    create_table :entret_checkers do |t|
      t.string   :uid,         null: false
      t.string   :uidfull,     null: false
      t.integer  :carrier,     null: false
      t.integer  :status,      null: false, default: 0
      t.datetime :executed_at, null: true

      t.timestamps
    end
  end
end
