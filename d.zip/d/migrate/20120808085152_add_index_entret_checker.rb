# -*- coding: utf-8 -*-

class AddIndexEntretChecker < ActiveRecord::Migration
  def up
    add_index :entret_checkers, :executed_at
  end

  def down
    remove_index :entret_checkers, :executed_at
  end
end
