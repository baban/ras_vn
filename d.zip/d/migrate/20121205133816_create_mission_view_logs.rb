# encoding: utf-8

class CreateMissionViewLogs < ActiveRecord::Migration
  def change
    create_table :mission_view_logs do |t|
      t.string  :user_id,    null: false
      t.integer :mission_id, null: false

      t.timestamps
    end
  end
end
