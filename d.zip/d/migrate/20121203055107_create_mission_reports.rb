# encoding: utf-8

class CreateMissionReports < ActiveRecord::Migration
  def change
    create_table :mission_reports do |t|
      t.string   :title,       null: false
      t.text     :content,     null: false, default:""
      t.boolean  :public,      null: true,  default: false
      t.integer  :mission_id,  null: false
      t.text     :comment,     null: true

      t.timestamps
    end
  end
end
