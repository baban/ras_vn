# encoding: utf-8

class CreateLUserentret < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `l_userentret` (
  `l_userentret_id` int(11) NOT NULL auto_increment,
  `uid` varchar(255) NOT NULL,
  `carrier` tinyint(4) NOT NULL,
  `course` tinyint(4) NOT NULL,
  `entret_dt` datetime NOT NULL,
  `entret_flg` tinyint(4) NOT NULL default '0',
  `re_flg` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`l_userentret_id`),
  KEY `s1_key` (`uid`),
  KEY `s2_key` (`entret_dt`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `l_userentret`"
  end
end
