# encoding: utf-8

class AddIndexArigatoResultCounts < ActiveRecord::Migration
  def up
    add_index :arigato_result_counts, :month
  end

  def down
    remove_index :arigato_result_counts, :month
  end
end
