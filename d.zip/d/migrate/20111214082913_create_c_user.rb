# encoding: utf-8

class CreateCUser < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `c_user` (
  `c_user_id` int(11) NOT NULL auto_increment,
  `cnt_dt` datetime NOT NULL,
  `carrier` tinyint(4) NOT NULL,
  `entry_cnt` int(11) NOT NULL default '0',
  `retire_cnt` int(11) NOT NULL default '0',
  `entret_cnt` int(11) NOT NULL default '0',
  `entry_total` int(11) NOT NULL default '0',
  `retire_total` int(11) NOT NULL default '0',
  `entret_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`c_user_id`),
  KEY `s1_key` (`cnt_dt`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `c_user`;"
  end
end
