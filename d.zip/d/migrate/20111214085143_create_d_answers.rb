# encoding: utf-8

class CreateDAnswers < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_answers` (
  `answer_id` bigint(20) NOT NULL auto_increment,
  `question_id` bigint(20) NOT NULL,
  `answerer_id` varchar(256) NOT NULL,
  `answer_body` text NOT NULL,
  `answer_dt` datetime NOT NULL,
  `answer_count` tinyint(4) default NULL,
  `answer_display_status` tinyint(4) NOT NULL default '0',
  `answer_open_flg` tinyint(4) NOT NULL default '1',
  `send_notice_mail_flg` tinyint(4) NOT NULL default '0',
  `thanks_body` text,
  `thanks_dt` datetime default NULL,
  `checked_flg` tinyint(4) default NULL,
  `a_shounin_flg` tinyint(4) NOT NULL default '1' COMMENT '回答の承認フラグ １:未承認の回答、２:アイウエオ様が承認済みの回答、３：内容に承認できず却下された回答',
  `thanks_open_flg` tinyint(4) default NULL,
  `send_thanks_notice_mail_flg` tinyint(4) default NULL,
  `del_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  `shounin_dt` datetime default NULL COMMENT '承認日付',
  PRIMARY KEY  (`answer_id`),
  KEY `s1_key` (`question_id`),
  KEY `s2_key` (`answerer_id`,`checked_flg`),
  KEY `s3_key` (`answer_id`,`answer_open_flg`,`del_flg`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=sjis;
SQL
    add_column :d_answers, :arigato_count, :integer, null: false, default: 0
  end

  def down
    execute "DROP TABLE `d_answers`"
  end
end
