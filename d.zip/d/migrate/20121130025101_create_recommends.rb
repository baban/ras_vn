# encoding: utf-8

class CreateRecommends < ActiveRecord::Migration
  def change
    create_table :recommends do |t|
      t.string   :title,    null: false, default: ''
      t.text     :content,  null: false, default: ''
      t.boolean  :public,   null: true,  default: false
      t.datetime :start_at, null: true,  default: false
      t.datetime :end_at,   null: true,  default: false
      t.timestamps
    end
  end
end
