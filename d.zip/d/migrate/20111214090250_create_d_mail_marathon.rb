# encoding; utf-8

class CreateDMailMarathon < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_mail_marathon` (
  `mail_marathon_id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `contents` text NOT NULL,
  `open_dt` datetime NOT NULL,
  `magazine_from` varchar(256) NOT NULL,
  `magazine_reply` varchar(256) NOT NULL,
  `magazine_bcc` varchar(256) default NULL,
  `magazine_status` tinyint(4) NOT NULL default '1',
  `magazine_sent_dc` int(11) NOT NULL default '0',
  `magazine_sent_au` int(11) NOT NULL default '0',
  `magazine_sent_sb` int(11) NOT NULL default '0',
  `magazine_sent_count_dc` int(11) NOT NULL default '0',
  `magazine_sent_count_au` int(11) NOT NULL default '0',
  `magazine_sent_count_sb` int(11) NOT NULL default '0',
  `magazine_sent_count` int(11) NOT NULL default '0',
  `open_flg` tinyint(4) NOT NULL default '1',
  `del_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  `timestamp` varchar(100) NOT NULL,
  PRIMARY KEY  (`mail_marathon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_mail_marathon`;"
  end
end
