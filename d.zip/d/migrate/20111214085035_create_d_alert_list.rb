# encoding: utf-8

class CreateDAlertList < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_alert_list` (
  `alert_id` bigint(20) NOT NULL auto_increment,
  `question_id` bigint(20) NOT NULL,
  `answerer_id` varchar(256) NOT NULL,
  `send_notice_mail_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`alert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_alert_list`"
  end
end
