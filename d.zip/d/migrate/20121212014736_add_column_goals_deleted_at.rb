# encoding: utf-8

class AddColumnGoalsDeletedAt < ActiveRecord::Migration
  def up
    add_column     :goals, :deleted_at, :datetime, null: true
  end

  def down
    remove_column :goals, :deleted_at
  end
end
