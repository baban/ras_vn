# encoding: utf-8

class CreateGoalLogs < ActiveRecord::Migration
  def change
    create_table :goal_logs do |t|
      t.integer :goal_id,     null: false
      t.integer :status,      null: false, default: 0
      t.date    :achieved_at, null: false
      t.timestamps
    end
  end
end
