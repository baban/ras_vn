# encoding: utf-8

class CreateSUserPasswords < ActiveRecord::Migration
  def self.up
    create_table :s_user_password do |t|
      t.string  :uid,      null: false
      t.string  :username, null: false
      t.integer :salt,     null: false
      t.string  :password, null: false
      t.timestamps
    end
    add_index :s_user_password, :uid, unique:true
    add_index :s_user_password, :username, unique:true
  end

  def self.down
    drop_table :s_user_password
  end
end
