# encoding: utf-8

class CreateGoals < ActiveRecord::Migration
  def change
    create_table :goals do |t|
      t.string   :user_id,     null: false
      t.integer  :genre,       null: false
      t.text     :title,       null: false
      t.integer  :status,      null: false, default: 0
      t.datetime :achieve_at,  null: true
      t.datetime :achieved_at, null: true

      t.timestamps
    end
  end
end
