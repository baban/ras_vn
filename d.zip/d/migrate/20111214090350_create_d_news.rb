# encoding: utf-8

class CreateDNews < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_news` (
  `news_id` bigint(20) NOT NULL auto_increment,
  `news_text` varchar(200) NOT NULL,
  `start_dt` datetime NOT NULL,
  `end_dt` datetime NOT NULL,
  `open_flg` tinyint(4) NOT NULL default '1',
  `del_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`news_id`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_news`"
  end
end
