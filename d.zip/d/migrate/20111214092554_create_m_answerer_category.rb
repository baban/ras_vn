# encoding: utf-8
class CreateMAnswererCategory < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `m_answerer_category` (
  `answerer_id` varchar(256) NOT NULL,
  `category_id` int(11) NOT NULL,
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`answerer_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `m_answerer_category`"
  end
end
