# encoding: utf-8

class AddIndexArigatoLogs < ActiveRecord::Migration
  def up
    # 実際にfindかけるのはユーザーがarigatoボタンを押したことがあるかどうかのチェックだけなので
    # indexはそれに対して特化して1個だけ入れておく
    # insert_掛けるときのindex再生成の負荷は読めないので、"時間があったら"...。"時間があったら"(大事なことなので2回言いました)
    # パフォーマンス計測して再作成する
    # べっ、別に面倒臭かったわけじゃないんだからねッ！
    add_index :arigato_logs, [:parent_type, :parent_id, :user_id]
  end

  def down
    remove_index :arigato_logs, column: [:parent_type, :parent_id, :user_id]
  end
end
