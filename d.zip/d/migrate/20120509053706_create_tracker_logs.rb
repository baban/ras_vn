# encoding: utf-8

class CreateTrackerLogs < ActiveRecord::Migration
  def change
    create_table :tracker_logs do |t|
      t.string   :session_id,   null: false
      t.string   :tracker_code, null: false
      t.datetime :completed_at, null: true
      t.datetime :limit_at,     null: false
      t.string   :user_id,      null: true
      t.string   :carrier,      null: true
      t.datetime :retired_at,   null: true
      t.timestamps
    end
  end
end

