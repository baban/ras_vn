# encoding: utf-8

class CreatePayment < ActiveRecord::Migration
  def change
    create_table :payment do |t|
      t.string  :uid,                 null: true,  default: ''
      t.string  :consumer_payment_id, null: true,  default: ''
      t.string  :transaction_id,      null: true,  default: ''
      t.string  :order_id,            null: true
      t.integer :status,              null: false, default: 0
      t.timestamps
    end
  end
end
