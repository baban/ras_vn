# encoding: utf-8

class AddColumnMissionsArigatoCount < ActiveRecord::Migration
  def up
    add_column    :missions, :arigato_count, :integer, null: false, default: 0
  end

  def down
    remove_column :missions, :arigato_count
  end
end
