# encoding: utf-8

class CreateDFailMailaddress < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_fail_mailaddress` (
  `fail_mail_address` varchar(256) NOT NULL,
  `fail_count` int(11) NOT NULL default '1',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`fail_mail_address`),
  KEY `s1_key` (`fail_mail_address`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_fail_mailaddress`"
  end
end
