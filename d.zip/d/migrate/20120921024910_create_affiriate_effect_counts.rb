# encoding: utf-8

class CreateAffiriateEffectCounts < ActiveRecord::Migration
  def change
    create_table :affiriate_effect_counts do |t|
      t.date    :month,          null: false
      t.string  :affiriate_type, null: false
      t.integer :amount1,        null: true
      t.integer :amount2,        null: true
      t.integer :amount3,        null: true
      t.integer :amount4,        null: true
      t.integer :amount5,        null: true
      t.integer :amount6,        null: true
      t.integer :amount7,        null: true
      t.integer :amount8,        null: true
      t.integer :amount9,        null: true
      t.integer :amount10,       null: true
      t.integer :amount11,       null: true
      t.integer :amount12,       null: true

      t.timestamps
    end
  end
end
