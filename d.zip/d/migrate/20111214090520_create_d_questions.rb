# encoding: utf-8

class CreateDQuestions < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_questions` (
  `question_id` bigint(20) NOT NULL auto_increment,
  `uid` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `question_title` varchar(50) NOT NULL,
  `question_body` text NOT NULL,
  `send_notice_mail_flg` tinyint(4) NOT NULL default '0',
  `deadline_flg` tinyint(4) NOT NULL default '1',
  `deadline_dt` datetime default NULL,
  `recency_answer_dt` datetime default NULL,
  `open_flg` tinyint(4) NOT NULL default '1',
  `q_kubun` tinyint(4) NOT NULL default '1' COMMENT '回答者区分 1:本田健さんへ質問（既存）、２:ナビさんへ質問',
  `q_editing_flg` tinyint(4) NOT NULL default '0' COMMENT '同時に回答できないように制御するフラグ。0:デフォルト １:回答中',
  `q_shounin_flg` tinyint(4) NOT NULL default '0' COMMENT '0:まだ回答がない質問 １:回答済みで未承認の質問、２:回答があってアイウエオ様が承認済みの質問、３：回答があったが、内容に問題あって却下された質問',
  `del_flg` tinyint(4) NOT NULL default '0',
  `alert_flg` tinyint(4) NOT NULL default '0',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`question_id`),
  KEY `s1_key` (`category_id`),
  KEY `s2_key` (`question_id`,`insert_dt`,`open_flg`,`del_flg`),
  KEY `s3_key` (`uid`,`insert_dt`,`del_flg`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_questions`"
  end
end
