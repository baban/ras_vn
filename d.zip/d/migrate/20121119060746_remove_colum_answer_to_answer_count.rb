# encoding: utf-8

# 使用していないカラムなのでいい加減に整理してしまう
class RemoveColumAnswerToAnswerCount < ActiveRecord::Migration
  def up
    remove_column :d_answers, :answer_count
  end

  def down
    add_column    :d_answers, :answer_count, :integer, null: true
  end
end
