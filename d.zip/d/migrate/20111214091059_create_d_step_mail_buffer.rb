# encoding: utf-8

class CreateDStepMailBuffer < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_step_mail_buffer` (
  `uid` varchar(255) NOT NULL,
  `nickname` varchar(256) default NULL,
  `mail_id` int(11) NOT NULL,
  `mail_address` varchar(256) NOT NULL,
  `magazine_from` varchar(256) NOT NULL,
  `magazine_reply` varchar(256) NOT NULL,
  `magazine_bcc` varchar(256) default NULL,
  `magazine_title` text NOT NULL,
  `magazine_body` text NOT NULL,
  `news_text` varchar(200) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_step_mail_buffer`"
  end
end
