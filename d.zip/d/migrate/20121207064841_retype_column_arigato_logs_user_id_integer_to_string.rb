# encoding: utf-8

class RetypeColumnArigatoLogsUserIdIntegerToString < ActiveRecord::Migration
  def up
    change_column :arigato_logs, :user_id, :string
  end

  def down
    change_column :arigato_logs, :user_id, :integer
  end
end
