# encoding: utf-8

class CreateDMailBuffer < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_mail_buffer` (
  `mail_id` bigint(20) NOT NULL auto_increment,
  `send_mail_kbn` tinyint(4) NOT NULL,
  `link_id` bigint(20) NOT NULL,
  `insert_dt` datetime NOT NULL,
  `sendt_dt` datetime default NULL,
  `mail_status` tinyint(4) NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`mail_id`),
  KEY `s1_key` (`insert_dt`,`mail_status`),
  KEY `s2_key` (`insert_dt`,`link_id`,`send_mail_kbn`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_mail_buffer`"
  end
end
