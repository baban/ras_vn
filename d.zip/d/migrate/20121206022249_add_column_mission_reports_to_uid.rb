# encoding: utf-8

class AddColumnMissionReportsToUid < ActiveRecord::Migration
  def up
    add_column :mission_reports, :user_id, :string, null: false
  end
  def down
    remove_column :mission_reports, :user_id
  end
end
