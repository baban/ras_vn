# encoding: utf-8

class CreatePasswordResets < ActiveRecord::Migration
  def change
    create_table :password_resets do |t|
      t.string   :uid,        null: false
      t.string   :key,        null: false
      t.integer  :status,     null: false, default: 0
      t.datetime :deleted_at, null: true
      t.timestamps
    end
    add_index :password_resets, :key
  end
end
