# encoding: utf-8

class CreateArigatoLogs < ActiveRecord::Migration
  def change
    create_table :arigato_logs do |t|
      t.string  :uid,    null: false
      t.integer :bbs_id, null: false
      t.timestamps
    end
  end
end
