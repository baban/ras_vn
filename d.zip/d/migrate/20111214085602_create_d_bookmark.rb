# encoding:utf-8

class CreateDBookmark < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_bookmark` (
  `uid` varchar(255) NOT NULL,
  `answer_id` bigint(20) NOT NULL,
  `bookmark_disp_order` int(11) default NULL,
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`uid`,`answer_id`),
  KEY `s1_key` (`uid`,`answer_id`,`bookmark_disp_order`),
  KEY `s2_key` (`uid`,`insert_dt`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_bookmark`"
  end
end
