# encoding: utf-8
class CreateLUserAffiriate < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `l_user_affiriate` (
  `affiriate_id` int(11) NOT NULL auto_increment,
  `uid` varchar(255) NOT NULL,
  `affiriate_code` varchar(60) default NULL,
  `affiriate_type` varchar(40) NOT NULL,
  `php_self` varchar(40) NOT NULL,
  `parameter` varchar(512) NOT NULL,
  `insert_dt` datetime NOT NULL,
  `limit_dt` datetime NOT NULL,
  `fix_flg` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`affiriate_id`),
  UNIQUE KEY `s1_key` (`uid`,`affiriate_type`),
  KEY `s2_key` (`affiriate_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `l_user_affiriate`"
  end
end
