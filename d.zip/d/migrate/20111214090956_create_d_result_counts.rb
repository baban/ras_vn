# encoding: utf-8

class CreateDResultCounts < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `d_result_counts` (
  `count_id` bigint(20) NOT NULL auto_increment,
  `sent_dt` datetime NOT NULL,
  `sent_count_sum` bigint(20) NOT NULL,
  `sent_count_ok` bigint(20) NOT NULL,
  `sent_count_error` bigint(20) NOT NULL,
  PRIMARY KEY  (`count_id`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `d_result_counts`"
  end
end
