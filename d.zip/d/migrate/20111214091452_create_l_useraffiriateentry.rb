# encoding: utf-8
class CreateLUseraffiriateentry < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `l_useraffiriateentry` (
  `l_useraffiriateentry_id` int(11) NOT NULL auto_increment,
  `uid` varchar(255) NOT NULL,
  `carrier` tinyint(4) NOT NULL,
  `affiriate_code` varchar(60) default NULL,
  `php_self` varchar(40) NOT NULL,
  `parameter` varchar(512) NOT NULL,
  `insert_dt` datetime NOT NULL,
  PRIMARY KEY  (`l_useraffiriateentry_id`),
  KEY `s1_key` (`uid`),
  KEY `s2_key` (`affiriate_code`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
    add_column :l_useraffiriateentry, :affiriate_type, :string,   null: true
    add_column :l_useraffiriateentry, :retired_at,     :datetime, null: true
  end

  def down
    execute "DROP TABLE `l_useraffiriateentry`"
  end
end
