# encoding: utf-8

class CreateArigatoResultCounts < ActiveRecord::Migration
  def change
    create_table :arigato_result_counts do |t|
      t.datetime :month,        null: false
      t.integer  :amount,       null: false, default: 0
      t.integer  :total_amount, null: false, default: 0

      t.timestamps
    end
  end
end
