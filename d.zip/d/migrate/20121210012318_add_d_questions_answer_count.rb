# encoding: utf-8

class AddDQuestionsAnswerCount < ActiveRecord::Migration
  def up
    add_column    :d_questions, :answer_count, :integer, null: false, default: 0
  end

  def down
    remove_column :d_questions, :answer_count
  end
end
