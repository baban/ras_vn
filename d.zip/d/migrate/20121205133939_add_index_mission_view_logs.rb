# encoding: utf-8

class AddIndexMissionViewLogs < ActiveRecord::Migration
  def up
    add_index    :mission_view_logs, :user_id
    add_index    :mission_view_logs, [:user_id,:mission_id], unique: true
  end

  def down
    remove_index :mission_view_logs, column:[:user_id]
    remove_index :mission_view_logs, column:[:user_id,:mission_id]
  end
end
