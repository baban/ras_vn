# encoding: utf-8
class CreateMAnswerer < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `m_answerer` (
  `answerer_id` varchar(256) NOT NULL,
  `answerer_nickname` varchar(256) NOT NULL,
  `navi_name` varchar(256) default NULL COMMENT 'ナビゲータ名',
  `answerer_mail` varchar(256) NOT NULL,
  `semina_area` varchar(256) default NULL COMMENT 'セミナの開催エリア',
  `profile_image` blob COMMENT 'プロフィール写真',
  `imgtype` varchar(256) default NULL COMMENT 'プロフィール写真タイプ',
  `width` int(11) default NULL COMMENT 'プロフィール画像横幅',
  `height` int(11) default NULL COMMENT 'プロフィール画像高さ',
  `comment` text COMMENT 'ナビさんの自己紹介',
  `notice_mail_flg` tinyint(4) NOT NULL default '1',
  `answerer_password` varchar(40) NOT NULL,
  `del_flg` tinyint(4) NOT NULL default '0' COMMENT '削除フラグ。0:未削除、1:削除',
  `admin_flg` tinyint(4) NOT NULL default '0' COMMENT '管理者かどうか判定するフラグ。0:一般ナビさん、1:アイウエオオフィス様とOKWave管理用',
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  `answer_dt` datetime NOT NULL COMMENT '最後に回答した日付',
  PRIMARY KEY  (`answerer_id`),
  KEY `s1_key` (`answerer_id`,`insert_dt`),
  KEY `s2_key` (`answerer_id`,`answerer_password`),
  KEY `s3_key` (`answerer_id`,`answerer_nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
    add_column :m_answerer, :arigato_count, :integer, null: false, default: 0
  end

  def down
    execute "DROP TABLE `m_answerer`;"
  end
end
