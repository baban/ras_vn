# encoding: utf-8

class CreateAlertPosts < ActiveRecord::Migration
  def change
    create_table :alert_posts do |t|
      t.string  :parent_type, null: false
      t.integer :parent_id,   null: false
      t.string  :user_id,     null: false
      t.text    :content,     null: false
      t.boolean :status,      null: false, default: false
      t.timestamps
    end
  end
end
