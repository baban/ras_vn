# encoding: utf-8
class CreateTDevice < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `t_device` (
  `t_device_id` int(11) NOT NULL auto_increment,
  `device_type` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `carrier` tinyint(4) NOT NULL default '0',
  `series_type` tinyint(4) NOT NULL default '0',
  `site_flg` tinyint(4) NOT NULL default '0',
  `flash_flg` tinyint(4) NOT NULL default '0',
  `flash_type` varchar(100) default '0',
  `gif_flg` tinyint(4) NOT NULL default '0',
  `gif_type` varchar(100) default '0',
  `jpg_flg` tinyint(4) NOT NULL default '0',
  `jpg_type` varchar(100) default '0',
  `png_flg` tinyint(4) NOT NULL default '0',
  `png_type` varchar(100) default '0',
  `emoji_flg` tinyint(4) NOT NULL default '0',
  `emoji_type` varchar(100) default '0',
  `tpl_flg` tinyint(4) NOT NULL default '0',
  `tpl_type` varchar(100) default '0',
  `ftpl_flg` tinyint(4) NOT NULL default '0',
  `ftpl_type` varchar(10) default '0',
  `open_flg` tinyint(4) NOT NULL default '0',
  `open_dt` datetime NOT NULL,
  `close_dt` datetime NOT NULL,
  `insert_dt` datetime NOT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY  (`t_device_id`),
  KEY `s1_key` (`device_type`),
  KEY `s2_key` (`carrier`),
  KEY `s3_key` (`series_type`),
  KEY `s4_key` (`open_dt`),
  KEY `s5_key` (`close_dt`)
) ENGINE=InnoDB AUTO_INCREMENT=433 DEFAULT CHARSET=sjis;
SQL
  end

  def down
    execute "DROP TABLE `t_device`"
  end
end
