# encoding: utf-8

class RecreateArigatoLogs < ActiveRecord::Migration
  def up
    drop_table :arigato_logs
    create_table :arigato_logs do |t|
      t.string  :parent_type, null: false
      t.integer :parent_id,   null: false
      t.string  :user_id,     null: false
      t.timestamps
    end
  end

  def down
    drop_table :arigato_logs
    create_table :arigato_logs do |t|
      t.string  :uid,    null: false
      t.integer :bbs_id, null: false
      t.timestamps
    end
  end
end
