# encoding: utf-8

class CreateSUserinfo < ActiveRecord::Migration
  def up
    execute <<SQL
CREATE TABLE `s_userinfo` (
  `uid` varchar(255) NOT NULL,
  `simple_flg` tinyint(4) default '0',
  `nickname` varchar(256) default NULL,
  `birthday` datetime default NULL,
  `sex` tinyint(4) default NULL,
  `mail_address` varchar(256) default NULL,
  `mail_flg` tinyint(4) default NULL COMMENT '1：メールマラソン配信する。2：メールマラソン配信しない。3：メールアドレスへの送信に失敗した為、現在送信が停止中',
  `notice_mail_flg` tinyint(4) default NULL COMMENT 'キキミミに合わせる為に作成するが、本来は「mail_flg」を調査して流用すべき',
  `family_name` varchar(256) default NULL,
  `first_name` varchar(256) default NULL,
  `family_name_kana` varchar(256) default NULL,
  `first_name_kana` varchar(256) default NULL,
  `postcode` varchar(7) default NULL,
  `prefecture` int(11) default '0',
  `address` varchar(256) default NULL,
  `init_send_flg` int(4) NOT NULL default '0' COMMENT '第１号のメールが送信済みかどうかのフラグ。０：デフォルト値（配信済み）、１：未配信',
  `last_mail_id` int(6) NOT NULL default '0' COMMENT 'メールマラソンID(号)',
  `last_sent_dt` datetime default NULL COMMENT '最後にメールしたメールマラソンの日付',
  PRIMARY KEY  (`uid`),
  KEY `s1_key` (`mail_address`),
  KEY `s2_key` (`nickname`),
  KEY `s3_key` (`prefecture`)
) ENGINE=InnoDB DEFAULT CHARSET=sjis;
SQL
  execute "ALTER TABLE s_userinfo ADD COLUMN `last_sent_yobi` tinyint(4) default NULL COMMENT 'メール配信を停止した曜日。再配信設定時は、この曜日を見て次の配信曜日を判断する。'"
  end

  def down
    execute "DROP TABLE IF EXISTS s_userinfo;"
  end
end
