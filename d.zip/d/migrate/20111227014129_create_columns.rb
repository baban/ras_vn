# encoding: utf-8

class CreateColumns < ActiveRecord::Migration
  def change
    create_table :columns do |t|
      t.string   :title,       null: false, default:''
      t.text     :content,     null: false, default:''
      t.boolean  :public,      null: true,  default: false
      t.datetime :start_at,    null: true,  default: false
      t.datetime :end_at,      null: true,  default: false
      t.integer  :category_id, null: false, default: 0
      t.timestamps
    end
  end
end
