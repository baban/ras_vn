# encoding: utf-8

class AddIndexesPayment < ActiveRecord::Migration
  def self.up
    add_index :payment, :consumer_payment_id
    add_index :payment, :transaction_id
    add_index :payment, :uid
  end

  def self.down
    remove_index :payment, :consumer_payment_id
    remove_index :payment, :transaction_id
    remove_index :payment, :uid
  end
end
