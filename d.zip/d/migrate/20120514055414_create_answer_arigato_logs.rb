# encoding: utf-8

class CreateAnswerArigatoLogs < ActiveRecord::Migration
  def change
    create_table :answer_arigato_logs do |t|
      t.string  :uid,       null: false
      t.integer :answer_id, null: false

      t.timestamps
    end
  end
end
