# encoding: utf-8

class Batch::MailBuffer < ActiveRecord::Base
  self.table_name= :d_mail_buffer

  # お礼通知メール
  def self.send_thanks_mails
    Rails.logger.info 'BatchMail_thanks:START'
    # 送信対象質問の取得
    buffers = self.where( send_mail_kbn: MailBuffer::Type::THANKS, mail_status: MailBuffer::Status::UNSEND )
    Rails.logger.info 'BatchMail_thanks_mail:'
    buffers.find_each do
      self.send_thanks_mail( buffer )
    end
    Rails.logger.info 'BatchMail_thanks:END'
  end

  # お礼メール送信
  def self.send_thanks_mail( buffer )
    answer = Answer.where( send_thanks_notice_mail_flg: 0, answer_id: buffer.link_id ).first
    question = Question.where( del_flg: 0, question_id: answer.question_id ).first
    answerer = AnswererMaster.find_by_answerer_id( answer.answerer_id )

    Rails.logger.info "BatchMail_thanks_question: #{question.inspect}"
    Rails.logger.info "BatchMail_thanks_answerer: #{answer.inspect}"

    return logger.error "メールアドレスが存在しないので送信を中断しました : #{answerer.inspect}" if answerer.answerer_mail.blank?

    begin
      ActiveRecord::Base.transaction do
        buffer.update_attributes( mail_status: 2, sendt_dt: Time.now )
        answer.update_attributes( send_thanks_notice_mail_flg: 1 )

        mail = UserMailer.thanks( question, answerer )
        mail.deliver unless %W[development test].include?(Rails.env)

        Rails.logger.info "BatchMail_thanks:SendSuccess [title]: #{question.question_title} [uid]: #{question.uid}"
      end
    rescue => e
      Rails.logger.info "BatchMail_thanks:SendError [title]: #{question.question_title} [uid]: #{question.uid}"
      return false
    end
    true
  end

  # 期限切れ通知メール 一斉送信
  # (BatchMail_deadline.php)
  def self.send_deadline_mails
    Rails.logger.info "BatchMail_deadline:START"
    sent_count = 0
    deadline_mails = self.where( " send_mail_kbn = 5 and mail_status = 1 " )
    deadline_mails.find_each do |buffer|
      ret = self.send_deadline_mail(buffer)
      next Rails.logger.error(" mail send error : #{buffer.inspect} ") unless ret

      sent_count += 1
    end
    Rails.logger.info "BatchMail_deadline:END"
    sent_count
  end

  # 期限切れ通知メール送信
  # @params [MailBuffer] buffer 送信したいメール
  def self.send_deadline_mail( buffer )
    q = Question.find_by_question_id( buffer.link_id ) # 期限切れメールとか件数多くないし毎回findでイイヨネ！
    Rails.logger.info "BatchMail_deadline_question: #{q.try(:uid)}"
    return false unless buffer.send_mail_kbn == 5 # 期限切れメール以外のメールは受け付けない
    return false unless q
    user = User.where( uid: q.uid ).where( " entry_flg = 1 and entry_dt <= ? ", q.insert_dt ).first
    return false unless user
    info = user.info
    return false unless info

    if info.notice_mail_flg == 1 && info.mail_address.present?
      ActiveRecord::Base.transaction do
        result = true
        # やっぱ開発環境でメールは飛ばしたくないのでこういう構成で
        if %W[development test].include?(Rails.env.to_s)
          Rails.logger.info "mail don't send because development enviroment "
        else
          result = UserMailer.question_over_deadline( info, q ).deliver
        end

        if result
          Rails.logger.info "BatchMail_deadline:SendSuccess [title]: #{q.question_title} [name]: #{info.nickname} "
          buffer.mail_status = 2
          buffer.update_dt = Time.now
          buffer.sendt_dt = Time.now
          buffer.save!
          return true
        end
      end
    else
      buffer.mail_status = 3
      buffer.sendt_dt = Time.now
      buffer.update_dt = Time.now
      buffer.save
    end
    false
  rescue => e
    p "BatchMail_deadline:SendError [title]: #{q.try(:question_title)} [name]: #{info.try(:nickname)}: error #{e.message} "
    Rails.logger.error "BatchMail_deadline:SendError [title]: #{q.try(:question_title)} [name]: #{info.try(:nickname)}: error #{e.message} "
    false
  end

  # 回答可能な回答者一覧を取得
  def self.mail_questions_answerers
    # 送信先回答者ID
    cate_array = CategoryMaster.where( del_flg: 0 ).select(:category_id)
    answerer_ids = AnswererCategoryMaster.where( "category_id in (#{cate_array.to_sql}) " ).select("distinct answerer_id")
    AnswererMaster.where( notice_mail_flg: 1 ).where( " answerer_id in (#{answerer_ids.to_sql})  " )
  end

  # 相談通知メール
  # 回答者に回答可能な質問をメールで飛ばす
  # バッチで実行
  # (BatchMail_question.php)
  def self.send_answerer_questions
    Rails.logger.info "BatchMail_question:START"

    category_ids = CategoryMaster.where( del_flg: 0 ).pluck(:category_id)

    answerers = self.mail_questions_answerers
    buffers = MailBuffer.where( mail_status: 1 ).where( send_mail_kbn: 1 )

    # ここでまとめて質問を取得して発行するSQLの数を減らす
    questions = Question.where( " question_id in (?) ", buffers.pluck(:link_id) )
                        .where( " category_id in (?) ", category_ids )
                        .where( q_kubun: 2 )
                        .where( send_notice_mail_flg: 0 )
                        .where( del_flg: 0 )
                        .where( deadline_flg: 1 )
                        .order(:insert_dt)

    count = questions.count
    Rails.logger.info "BatchMail_question_count:#{count}"

    # 質問がない場合は、メール送信しない
    b_cnt, q_cnt = nil, nil
    if count > 0
      # メール送信
      answerers.each do |answerer|
        ret = true
        ret = AnswererMailer.unanswerd_questions( answerer, questions, count ).deliver unless %W[development test].include?(Rails.env)

        if ret
          Rails.logger.info "BatchMail_question:SendSuccess"
        else
          Rails.logger.error "BatchMail_question:Error"
        end
      end
      q_cnt = questions.update_all( send_notice_mail_flg: 1 )
      b_cnt = buffers.update_all( mail_status: 2, sendt_dt: Time.now )
      Rails.logger.info "BatchMail_question:q_cnt : #{q_cnt} "
      Rails.logger.info "BatchMail_question:b_cnt : #{b_cnt} "
    end
    Rails.logger.info "BatchMail_question:END"
    [b_cnt, q_cnt]
  end
end
