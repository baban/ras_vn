# encoding: utf-8

class Batch::ArigatoResultCount < ActiveRecord::Base
  # 過去数カ月分の集計は
  # (0..10).each { |i| ArigatoResultCount.aggrigation( Time.now-i.months ) }
  def self.aggrigation( month = Time.now )
    month = month.to_datetime
    amount = AnswerArigatoLog.where( created_at: month.beginning_of_month..month.end_of_month ).count
    row = self.find_or_create_by_month( month.beginning_of_month )
    row.amount = amount
    row.total_amount = AnswerArigatoLog.where( " created_at < ? ", month.end_of_month ).count
    row.save
    row
  end
end
