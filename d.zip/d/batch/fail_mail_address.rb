# encoding: utf-8

require "mail"

class Batch::FailMailAddress < ActiveRecord::Base
  self.table_name= :d_fail_mailaddress

  MAIL_MAGAZINE_ERROR_COUNT = 3

  # エラーメールを処理する
  # (receiveErrormail.php)
  # エラーメールを既定のディレクトリから一括で取り出して、終わったら消す方式なので
  # 事前に postfix の「/etc/aliases」を編集して以下のように変えてもらっておく!
  #
  # before:
  # errm
  # mail_kenhonda: "| /usr/bin/php -q /home/www/kenhonda/apps/mobile/bat/receiveErrormail.php"
  #
  # after:
  # errmail_kenhonda: "> /var/www/dev.kenhonda.okwave.jp/share/log/error_mails/mail_`date +"%Y%m%d%H%m%S"`.txt"
  #
  # @oarams [String] dir メール一覧があるディレクトリ
  # @return [Integer] 処理したメールの数
  def self.receives( dir = File.join(Rails.root.to_path, "log/error_mails" ) )
    Rails.logger.info "receiveErrormail:START"
    cnt = 0
    Dir::glob( File.join(dir, "mail_*.txt") ).each_with_index do |filename,i|
      self.receive( IO.read( filename ) )
      FileUtils.mv(filename, File.join("#{dir}_backup/"))
      cnt = i+1
    end
    Rails.logger.info "receiveErrormail:[registed mail_count:#{cnt}] ...END"
    cnt
  end

  # エラーメールを受信する
  # @params [String] mail_txt
  # @return [FailMailAddress] カラムのモデル
  def self.receive( mail_txt = STDIN.read )
    mail_address = self.parse( mail_txt )
    fail_mail    = self.regist( mail_address )
    fail_mail
  end

  # エラーメールの中身を解析して、その人のメールアドレスを取得する
  #
  # @params [String] mail_txt メールほヘッダを含む全文
  # @return [String] 抜き取った送信失敗したメールアドレス
  def self.parse( mail_txt )
    Rails.logger.info "receiveErrormail: body :mail_txt: #{mail_txt}"
    mail = Mail.read_from_string( mail_txt )
    # メールからデータ取得
    Rails.logger.info "receiveErrormail:mail.inspect: #{mail.inspect}"

    unless mail
      Rails.logger.error "receiveErrormail: It is not normal mail:END"
      return
    end
    # MAILER-DAEMON からのメールかをチェック
    unless mail.try(:from).try(:first).to_s.match("MAILER-DAEMON")
      Rails.logger.error "receiveErrormail:not error mail:END"
      return
    end

    # 本文（BODY）を取得
    body = mail.body
    Rails.logger.info "receiveErrormail: mail.body : #{body}"

    return unless body

    # 本文中にメールアドレスが無いかチェック
    email_reg = /([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+/ # メールアドレス判定用用の正規表現
    mail_address = body.match(email_reg).to_a.first
    
    Rails.logger.info "ERROR MAIL ADDRESS : #{mail_address}"

    mail_address
  end

  # データ登録
  def self.regist( mail_address )
    Rails.logger.info "BatchMail_mailmagazine fail_mailaddress : #{mail_address} "
    return unless mail_address.present?
    fail_mail = self.find_by_fail_mail_address(mail_address)
    
    ActiveRecord::Base.transaction do
      if fail_mail
        fail_mail.fail_count += 1
        fail_mail.update_dt = Time.now
      else
        fail_mail = self.new
        fail_mail.fail_mail_address = mail_address
      end
      fail_mail.save
    end
    
    fail_mail
  end

  # batchから使用
  # 一定回数以上送信を失敗したメールをテーブルから削除する
  # エラーメールアドレス削除バッチ
  # (BatchChk_erroraddr_del.php)
  def self.overdoesed_error_mails_delete
    Rails.logger.info "BatchChk_erroraddr_del:START"

    send_count=0
    error_addresses = self.where( " fail_count >= ? ", MAIL_MAGAZINE_ERROR_COUNT ).pluck(:fail_mail_address)
    error_addresses.each_with_index do |addr,i|
      ActiveRecord::Base.transaction do
        send_count = i+1
        # s_userinfoのメールマガジン受信フラグをアップデート
        SUserinfo.where( mail_address: addr ).update_all( mail_flg: 3 )
        # メールマガジン送信未達アドレステーブルから処理を行ったメールアドレスを物理削除
        self.where( fail_mail_address: addr ).delete_all
      end
    end

    Rails.logger.info "BatchChk_erroraddr_del:END"
    send_count
  end
end
