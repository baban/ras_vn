# encoding: utf-8

class Batch::Answer < ActiveRecord::Base
  self.table_name= :d_answers
  belongs_to :d_questions
  belongs_to :d_bookmark
  has_many :bookmarks, foreign_key: :answer_id
  has_one :d_questions, foreign_key: :question_id, class_name: Question

  # お礼をいう時はthanks_dtに値が入るのを条件に使用
  validates :thanks_body, presence:{ message: "には文章を入力して下さい" }, if:->(o){ !o.thanks_dt.nil? }

  default_scope order: :answer_id
  paginates_per 10

  # バッチから実行
  # ブロックされたままの質問を解除して回答権を戻す(BatchChk_answerBlock.php)
  def self.return_blocked_answer
    Rails.logger.info "BatchChk_answerBlock:START"
    question_ids = Question.where( " deadline_flg = 1 and q_editing_flg = 1 " ).where( del_flg: 0 ).pluck(:question_id)
    cnt = Question.where( " question_id in (?) ", question_ids ).update_all( q_editing_flg: 0 )
    Rails.logger.info "BatchChk_answerBlock:END"
    cnt
  end
end

