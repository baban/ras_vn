# encoding: utf-8

class Batch::PasswordReset < ActiveRecord::Base
  # メールを送って48時間以上更新処理がない場合は
  # 期限切れ処理を行う (バッチから呼ばれる)
  # @return [Integer] 消した行数
  def self.expire
    count = self.where( " created_at < ? ", Time.now - 48.hours ).delete_all
    logger.error " password reset : expired #{count} rows ...  "
    count
  end
end
