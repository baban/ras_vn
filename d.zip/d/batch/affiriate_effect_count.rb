# encoding: utf-8

class Batch::AffiriateEffectCount < ActiveRecord::Base
  # 初期データの無い状態では以下のコードをコンソールにコピーして初期の集計データを作成して下さい
  # 12ヶ月前までの集計結果を作成
  # Affiriate::COMPANY.each{ |affiriate_type,name| (0..12).each{ |i|; Batch::AffiriateEffectCount.aggrigation_by_affiriate_type( affiriate_type, Date.today-i.month ) } }
  # すべての会社の今日の集計結果を作成
  def self.aggrigation
    Affiriate::COMPANY.each do |affiriate_type,name|
      self.aggrigation_by_affiriate_type( affiriate_type )
      self.aggrigation_by_affiriate_type( affiriate_type + 100 )
    end
  end

  # バッチで集計して今月分のアフィリエイト効果測定
  # 月を指定して、過去のデータを最終型したい時は第2引数で数字を指定する
  # @params [String] affiriate_type アフィリエイト会社
  # @params [Date] month 集計したい月
  # @return [Array] 月毎の集計されたユーザー数
  def self.aggrigation_by_affiriate_type( affiriate_type, month = Date.today )
    month = month.to_datetime
    row = self.find_or_create_by_affiriate_type_and_month( affiriate_type, month.beginning_of_month )
    relation = UserAffiriateEntryLog.where( affiriate_type: affiriate_type )
    counts = (0..11).map do |back|
      calc_mon = month - back.month
      cnt = relation.where( insert_dt: calc_mon.beginning_of_month..calc_mon.end_of_month ).where( " retired_at IS NULL OR retired_at > ? ", month.end_of_month ).count
      row["amount#{back+1}"] = cnt
      cnt
    end
    row.save
    row
  end
end
