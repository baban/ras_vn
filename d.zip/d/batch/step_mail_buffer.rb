# encoding: utf-8

class Batch::StepMailBuffer < ActiveRecord::Base
  self.table_name= :d_step_mail_buffer

  # 「d_step_mail_buffer」テーブルから送信用のデータを取得して順番に送信
  # (Batch_SendMailmagazine.php)
  def self.send_mail_magazine
    # バッファテーブルに文面と送信者の一覧を登録
    self.create_sendmail_marathon_list
    # バッファから取り出したデータを順番に送信
    self.send_buffered_mails
  end

  # 日々のメールマラソン送信用のデータを作成して「d_step_mail_buffer」テーブルに格納
  # (Batch_create_sendmail_marathon_list.php)
  def self.create_sendmail_marathon_list( send_type = MAILMAGAZINE_SEND_TYPE )
    Rails.logger.info " Batch_create_sendmail_marathon_list: START "
    Rails.logger.info " now_yobi : #{Time.now.wday} "

    self.delete_all.tap { |count| Rails.logger.info "Batch_create_sendmail_marathon_list: 前回未削除送信用データを、[#{count}]件削除しました。" }

    news = News.visibles.first

    # selectを繰り返したくないので配信方法毎に効率化されたメール取得方法のロジックを隠蔽して保存
    # 適切な大きさで配信データをメールにキャッシュします
    mail_cache = self.create_mail_cache( send_type )

    # メールを送っていいユーザーのみを絞り出し
    user_infos = self.mail_senders_info
    user_infos.find_each( batch_size: 500 ) do |info|
      # 同じidのカラムはselectしないで取得させるため mail_cache に過去のselect結果をキャッシュさせておく
      Rails.logger.info " mail_marathon uid : #{info.uid}, last_mail_id : #{info.last_mail_id} "
      mail_marathon = mail_cache.call(info)

      next Rails.logger.info("cannot get mail_marathon data last_mail_id : #{info.last_mail_id}, uid : #{info.uid}") unless mail_marathon

      # 配信して良いユーザーだったかを再チェック
      next unless self.send_user_check( info, send_type )

      self.create_step_mail_buffer(info, mail_marathon, news)
    end
  end

  # メールマガジンのデータを取得するところの抽象化
  def self.create_mail_cache( send_type = MAILMAGAZINE_SEND_TYPE )
    case send_type
    when :step_mail
      # ここでメールマラソンのデータをまとめてキャッシュして、SQLの発行回数を減らす
      mail_cache = MailMarathon.visibles.where( magazine_status: 1 ).inject({}) { |h, mail_marathon| h[mail_marathon.mail_marathon_id] = mail_marathon; h }
      return ->(info){ mail_cache[info.last_mail_id] }
    when :reserved_mail
      # 今日の配信すべきメールを取得する
      d = DateTime.now
      mail = MailMarathon.visibles.where( magazine_status: 1 ).where( open_dt: d.beginning_of_day..d.end_of_day ).first
      return ->(info){ mail }
    end
  end

  # このユーザーにメールを配信していいのかをチェックする
  # 通常 mail_flg に依存しないチェックの場合、配信開始日くらいしか無いので
  # このメソッドは配信開始日のチェックを行なっているといっても過言ではない
  # じゃあメソッド名おかしくね？ってなるけど正直今のままで暫く遅延評価する
  # @param [SUserinfo] 配信チェック対象者
  # @param [Bool] 配信OKな相手ならtrue
  def self.send_user_check( info, send_type = MAILMAGAZINE_SEND_TYPE )
    # 実は配信ユーザーチェックに五月蝿い仕様は本田健だけなので、他の案件は自動でtrue
    return true unless APP_NAME=="kenhonda"

    init_send_flg = info.init_send_flg

    # '日:0', '月:1', '火:2', '水:3', '木:4', '金:5', '土:6'
    now_yobi = Date.today.wday
    # 入会したばけりで第１号のメールが送信されていないユーザ
    if init_send_flg == 1
      Rails.logger.info "初回の配信対象外曜日でスキップされたユーザ : #{info.uid} "
      # 月曜日でない場合は、送信対象外
      return if now_yobi != 1
    end

    # 一度退会したユーザ、若しくはプロフィール変更でメール設定を「受信しない」から「受信」へ変更ユーザは、停止した曜日から続きの曜日を配信するように
    unless info.last_sent_yobi == 0 || info.last_sent_yobi.blank?
      if info.last_sent_yobi == now_yobi
        Rails.logger.info "前回の停止曜日から続き号が配信 : UID=#{info.uid} "
      else
        return
      end
    end

    true
  end

  # メールを送るべき相手を絞り込んで、相手のs_userinfoテーブルの中身を返す
  # @return [Array] メール送れる人のSUserinfo一覧
  def self.mail_senders_info
    uids = User.entried.select(:uid)
    SUserinfo.where( " uid in (#{uids.to_sql}) " ).where( mail_flg: 1 ).where( " mail_address IS NOT NULL and mail_address != ? ", "" )
  end

  # step_mail_bufferにデータを挿入
  # @params [SUserinfo] info 送信するユーザーの情報
  # @params [MailMarathon] mail_marathon ユーザーに送信するメールマラソンの文面データ
  # @params [News] news メールの最後に挿入するお知らせ
  # @return [StepMailBuffer | false] 送信するメールのバッファ。失敗するとfalse
  def self.create_step_mail_buffer(info, mail_marathon, news)
    return !Rails.logger.error("user info not found")     unless info.is_a?(SUserinfo)
    return !Rails.logger.error("mail_marathon_not_found") unless mail_marathon.is_a?(MailMarathon)

    columns = {
      uid: info.uid,
      nickname: info.nickname,
      mail_id: mail_marathon.mail_marathon_id,
      mail_address: info.mail_address,
      magazine_from: mail_marathon.magazine_from,
      magazine_reply: mail_marathon.magazine_reply,
      magazine_bcc: mail_marathon.magazine_bcc,
      magazine_title: mail_marathon.title,
      magazine_body: mail_marathon.contents,
      news_text: news.try(:news_text).to_s,
    }

    buffer = self.create( columns, without_protection: true )

    Rails.logger.info "Batch_create_sendmail_marathon_list d_step_mail_buffer:"
    buffer
  end

  # メール送信処理メソッド
  # 結果の保存はやるが出来るだけ送信処理のみに特化する
  # (BatchMail_mailmagazine.php)
  # @params [Bool] force_mail_test_flg 開発環境でメールを送信する部分は動かないようにしているので、trueを入れるとそれをキャンセルする
  # @return [MailMarathonResultCount] メール送信結果のテーブル
  def self.send_buffered_mails( force_mail_test_flg = false )
    Rails.logger.info "Batch_SendMailmagazine: START---------------"
    ok_count = error_count = 0
    sent_dt = Time.now

    self.find_each do |buffer|
      begin
        log_message = {
          uid: buffer.uid,
          mail_address: buffer.mail_address,
          magazine_from: buffer.magazine_from,
          title: buffer.magazine_title,
        }.map{|k,v| "#{k} : #{v}" }*" , "
        Rails.logger.info "Batch_SendMailmagazine: #{log_message}"

        # テスト系の環境でない場合はメールを送信
        ret = true
        ret = UserMailer.mail_magazine( buffer ).deliver if !force_mail_test_flg and ![:test,:development].include?(Rails.env.to_sym)

        self.after_send_mail( ret, buffer, sent_dt )

        ok_count += 1
      rescue => e
        Rails.logger.error "mail_magazine_send_error : buffer : #{buffer.inspect} : error : #{e.inspect} "
        error_count += 1
      end
    end
    # 不要になったバッファテーブルを削除する。
    Batch::StepMailBuffer.delete_all.tap{ |count| Rails.logger.info "Batch_create_sendmail_marathon_list: 前回未削除送信用データを、#{count}件削除しました。" }

    ret = MailMarathonResultCount.create( sent_dt: sent_dt, sent_count_sum: (ok_count + error_count), sent_count_ok: ok_count, sent_count_error: error_count )
    Rails.logger.info "Batch_SendMailmagazine: END---------------"
    ret
  end

  # 指定されたユーザーのメール情報を送信済にする
  # @params [MailBuffer] buffer メール情報のモデル
  # @params [DateTime] sent_dt 送信日
  # @return [SUserinfo] 更新後のユーザー情報
  def self.update_user_mail_sended( buffer, sent_dt )
    Rails.logger.info "Update s_userinfo : [uid]: #{buffer.uid} [last_mail_id]: #{buffer.mail_id}"
    info = SUserinfo.find_by_uid(buffer.uid)
    Rails.logger.info "更新前の USerInfo: [uid]:#{info.uid} [last_mail_id]:#{info.last_mail_id} [mail_address]:#{info.mail_address}"

    info.init_send_flg = 0
    info.last_mail_id = buffer.mail_id
    info.last_sent_yobi = 0
    info.last_sent_dt = sent_dt
    result = info.save
    Rails.logger.info "更新後の USerInfo: [result]:#{result} [uid]:#{info.uid} [last_mail_id]:#{info.last_mail_id} [mail_address]:#{info.mail_address}"
    info
  end

  # メール送信後に必要な処理を記述する
  # @param [Boolean] ret 送信成功か失敗か
  # @param [StepMailBuffer] buffer 送信待ちメール
  # @param [Time] sentd_dt 送信日時
  # @return [Boolean | FailMailAddress] 送信成功時と失敗時で異なる
  def self.after_send_mail( ret, buffer, sent_dt )
    # 送信成功
    Rails.logger.info "BatchMail_mailmagazine:SendSuccess : [title]: #{buffer.magazine_title} [name]: #{buffer.nickname} [uid] : #{buffer.uid}"
    # ユーザ情報テーブルを更新
    self.update_user_mail_sended( buffer, sent_dt )
  end
end
