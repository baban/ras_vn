# encoding: utf-8

class Batch::Question < ActiveRecord::Base
  self.table_name= :d_questions

  # 期限切れ相談削除 & メールで通知
  # 実はこんまり案件では使用していないですよね…
  # (Batch_deadline.php)
  def self.deadlines_delete_and_mailsend
    self.delete_deadlined
    Batch::MailBuffer.send_deadline_mails
  end

  # 期限切れの相談をテーブルから削除する
  # (BatchChk_deadline.php)
  def self.delete_deadlined
    Rails.logger.info "BatchChk_deadline:START"
    questions = self.where( answer_count: [nil,0], del_flg: 0 ).where( " deadline_dt < ? ", Time.now )
    questions = questions.where( q_kubun: 2 ) if APP_NAME=="kenhonda"
    Rails.logger.info "BatchChk_deadline_questions:#{questions.size}"
    ActiveRecord::Base.transaction do
      questions.each { |question| Batch::MailBuffer.create( send_mail_kbn: 5, link_id: question.id, mail_status: 1 ) }
      questions.update_all( del_flg: 1 ).tap { |count| Rails.logger.info "テーブルを#{count}件更新しました" }
    end
    Rails.logger.info "BatchChk_deadline:END"
    questions
  end
end
