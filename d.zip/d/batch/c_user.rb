# encoding: utf-8

class Batch::CUser < ActiveRecord::Base
  self.table_name= :c_user

  default_scope order: 'c_user_id DESC'
  paginates_per 30

  scope :group_mode_by,->(mode) do
    group("cnt_dt")
  end

  scope :by_month,->(end_dt) { CUser.order(:cnt_dt => :asc).where( "cnt_dt between ? and ?", end_dt.to_date.beginning_of_month, end_dt.to_date.end_of_month ) }


  # 日時、会員集計バッチ
  # userCnt.php
  # @params [Date] today 集計したい日
  #
  # 移行手順
  # (Date.parse( "2012-05-08" )..Date.parse("2012-07-18")).map { |d| CUser.daily_user_count(d) }
  def self.daily_user_count( today = Time.now )
    # 機能の入会、退会分をデータとして保存
    yesterday = today.yesterday
    Rails.logger.info "daily_user_count : cnt_dt : #{yesterday}"
    entret_per_day = UserEntretLog
                       .where(" entret_dt between ? and ? ", yesterday.beginning_of_day, yesterday.end_of_day)
                       .group(:carrier).group(:entret_flg).count

    c_users = []
    (1..6).map do |carrier|
      # 既に計算したデータが存在している場合は処理をキャンセル
      c_user = CUser.where( " carrier = ? ", carrier ).where( " cnt_dt between ? and ? ", yesterday.beginning_of_day, yesterday.end_of_day ).first

      next if c_user

      yesterday_data = CUser.where( " carrier = ? ", carrier ).where( " cnt_dt between ? and ? ", (today - 2.days).beginning_of_day, (today - 2.days).end_of_day ).first

      entry, retire = entret_per_day[[carrier,1]].to_i, entret_per_day[[carrier,0]].to_i
      h = {
        cnt_dt: yesterday.beginning_of_day,
        carrier: carrier,
        entry_cnt: entry,
        retire_cnt: retire,
        entret_cnt: entry - retire,
        entry_total: yesterday_data.try(:entry_total).to_i + entry,
        retire_total: yesterday_data.try(:retire_total).to_i + retire,
        entret_total: yesterday_data.try(:entret_total).to_i + (entry - retire),
      }
      c_users.push( CUser.create(h) )
    end
    Rails.logger.info "daily_user_count finished"
    c_users
  end

  def self.carrier_users(month)
    carrier_names = CARRIER_NAMES
    # 名前と番号
    carrier_table = {}
    carrier_names.each do |number,name|
      carrier_table[number] = {
        number: number,
        name: name,
        entry_total:  0,
        retire_total: 0,
        entret_total: 0,
      }
    end

    # キャリアごとの月末ユーザー数
    carrier_counts = ->(yesterday){
      relation = CUser.unscoped.where( " cnt_dt between ? and ? ", yesterday.beginning_of_day, yesterday.end_of_day )
      (1..6).map{ |carrier| relation.where( " carrier = ? ", carrier ).last }.select{ |o| o }
    }.call(month.yesterday)

    # 総会員数
    carrier_counts.each do |carrier_count|
      carrier_table[carrier_count.carrier][:entry_total]  = carrier_count.try(:entry_total)
      carrier_table[carrier_count.carrier][:retire_total] = carrier_count.try(:retire_total)
      carrier_table[carrier_count.carrier][:entret_total] = carrier_count.entry_total - carrier_count.retire_total
    end

    # 今月入会したユーザーだけを計算
    self.carrier_active_users(month).each do |carrier,pay_total|
      carrier_table[carrier][:payment_total] = pay_total
    end

    # 表示しないキャリア情報を削除
    carrier_table.delete(0)
    carrier_table.delete(7)

    # 総計行 作成 & 挿入
    carrier_table["--"] = {
      number: "--",
      name: "総計",
      payment_total: carrier_table.map{ |k,h| h[:payment_total] }.sum,
      entry_total:   carrier_table.map{ |k,h| h[:entry_total]   }.sum,
      retire_total:  carrier_table.map{ |k,h| h[:retire_total]  }.sum,
      entret_total:  carrier_table.map{ |k,h| h[:entret_total]  }.sum,
    }

    carrier_table.map{ |num,h| Struct.new(*h.keys).new(*h.values) }
  end

  # 課金ユーザー数計算
  def self.carrier_active_users( month )
    (1..6).map do |carrier|
      monthly_data = CUser.unscoped.where( " carrier = ? ", carrier ).where( " cnt_dt between ? and ? ", month.beginning_of_month, month.end_of_month ).order(:cnt_dt)
      monthly_data_first, *monthly_data = monthly_data
      pay_total =
        monthly_data_first.try(:entret_total).to_i + # 月初のアクティブユーザー
        monthly_data.map(&:entry_cnt).sum # 今月中入会ユーザー
      [carrier, pay_total]
    end
  end

  # 月次でユーザーの入会、退会状況を分かるようにする
  def self.monthly_users( month )
    carrier_counts = CUser
      .where( " cnt_dt between ? and ? ", month.beginning_of_month, month.end_of_month )
      .select(:carrier)
      .select(CUser.arel_table[:entry_cnt].sum.as("entry_cnt"))
      .select(CUser.arel_table[:retire_cnt].sum.as("retire_cnt"))
      .select(CUser.arel_table[:entret_cnt].sum.as("entret_cnt"))
      .group(:carrier)

    carrier_names = CARRIER_NAMES
    # 名前と番号
    carrier_table = {}
    carrier_names.each do |number,name|
      carrier_table[number] = {
        number: number,
        name: name,
        entry_cnt: 0,
        retire_cnt: 0,
        entret_cnt: 0,
      }
    end

    carrier_counts.each do |carrier_count|
      carrier_table[carrier_count.carrier][:entry_cnt]  = carrier_count.entry_cnt
      carrier_table[carrier_count.carrier][:retire_cnt] = carrier_count.retire_cnt
      carrier_table[carrier_count.carrier][:entret_cnt] = carrier_count.entret_cnt
    end

    # 表示しないキャリア情報を削除
    carrier_table.delete(0)
    carrier_table.delete(7)

    # 総計
    carrier_table["--"] = {
      number: "--",
      name: "総計",
      entry_cnt:  carrier_table.map{ |k,h| h[:entry_cnt] }.sum,
      retire_cnt: carrier_table.map{ |k,h| h[:retire_cnt] }.sum,
      entret_cnt: carrier_table.map{ |k,h| h[:entret_cnt] }.sum,
    }

    carrier_table.map{ |num,h| Struct.new(*h.keys).new(*h.values) }
  end

  # 日次入退会者数
  # @param [Time] month 集計を行いたい月
  # @param [Array] carrier_nums 集計を行いたいキャリアの番号の一覧
  # @return [Array] 結果の配列
  def self.daily_count( month, carrier_nums )
    selecter=[
      "cnt_dt",
      "sum(entry_cnt)  as entry_cnt",
      "sum(retire_cnt) as retire_cnt",
      "sum(entret_cnt) as entret_cnt",
    ]
    # テーブルからデータを取り出し
    statistics = CUser.select(selecter).where( " carrier in (?) ", carrier_nums ).where( " cnt_dt between ? and ? ", month.beginning_of_month, month.end_of_month ).group(:cnt_dt).to_a
    # カラムのデータをそれぞれ表示用に整形
    statistics = statistics.map do |stat|
      {
        cnt_dt:stat.cnt_dt.strftime("%Y-%m-%d"),
        entry_cnt: stat.entry_cnt.to_i,
        retire_cnt: stat.retire_cnt.to_i,
        entret_cnt: stat.entret_cnt.to_i,
      }
    end
    # 合計を求めて末尾に挿入
    statistics<< {
      cnt_dt: "合計",
      entry_cnt:  statistics.map { |stat| stat[:entry_cnt] }.sum,
      retire_cnt: statistics.map { |stat| stat[:retire_cnt] }.sum,
      entret_cnt: statistics.map { |stat| stat[:entret_cnt] }.sum,
    }

    statistics = statistics.map{ |h| Struct.new(*h.keys).new(*h.values) }
  end
end
